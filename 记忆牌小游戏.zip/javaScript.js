(function() {
	let tm = 5
	let sum = document.getElementById('st')
	sum.innerHTML = `你还剩5秒可以查看`
	let aaa = setInterval(() => {
		tm--
		sum.innerHTML = `你还剩${tm}秒可以查看`
		if (tm == 0) {
			clearInterval(aaa)
			sum.innerHTML = ``
		}
	}, 1000)
	//所有图标
	let icon = ['🍎', '🍊', '🍇', '🍓', '🍒', '🍑', '🥝', '🌽', '🍎', '🍊', '🍇', '🍓', '🍒', '🍑', '🥝', '🌽']
	let icon_new = []
	//把里面16个节点转换成数组
	let blue = Array.from($('.poker .front'))
	let All = $('.poker')
	console.log(All)
	// console.log(icon)
	console.log(blue)
//从后向前遍历数组，每次随机选取一个位置，与当前位置进行交换
	function shuffle(array) {
		let currentIndex = array.length,randomIndex
		while (currentIndex != 0) {
			//取剩余项选出随机项插入当前项位置前面
			randomIndex = Math.floor(Math.random() * currentIndex);
			currentIndex--
			//交换
			[array[currentIndex], array[randomIndex]] = [array[randomIndex], array[currentIndex]]
		}
		return array
	}
	shuffle(icon)
	//创建一个变量存储已经插入了多少个当前图标
	let counter = {}
	blue.forEach(box => {
		//如果box前面节点里就有两个设置的图标，那就跳过这次循环
		if (counter[icon_new[-1]] === 2) {
			return
		}
		//让在图标数组中的位置不重复，长度先建立为0，每加一个再push到icon_new里
		if (icon_new.length >= icon / length) icon_new = []
		let rd = Math.floor(Math.random() * icon.length)
		let setIcon = icon[rd]
		//检查要插入的图标是否超过上限，若超过则重新选取另一个
		while (counter[setIcon] === 2) {
			rd = Math.floor(Math.random() * icon.length)
			setIcon = icon[rd]
		}
		//插入HTML代码块
		box.innerHTML = `<div>${setIcon}</div>`

		if (counter[setIcon]) {
			counter[setIcon]++
		} else {
			counter[setIcon] = 1
		}
	})
	// Array.from(blue).forEach(box => All.append(box.cloneNode(true)));
	let timeover = 5
	const count = document.getElementById('st')
	//把所有牌都翻开，然后等待5秒后再把所有牌都翻回去
	document.querySelectorAll(".poker").forEach(function(poker) {
		poker.classList.add("open")
	})
	setTimeout(function() {
		document.querySelectorAll(".poker").forEach(function(poker) {
			poker.classList.remove("open")
		})
	}, 5000)
	let openedCards = []
	document.querySelectorAll(".poker").forEach(function(poker) {
		poker.addEventListener("click", function() {
			// 如果已经翻开了两张牌，直接返回
			if (openedCards.length >= 2) {
				return
			}

			// 给poker添加open样式类，翻开牌
			this.classList.add("open")

			// 将这张牌添加到已翻开的牌列表中
			openedCards.push(this)

			// 如果已经翻开了两张牌，检查它们是否匹配
			if (openedCards.length === 2) {
				let card1 = openedCards[0]
				let card2 = openedCards[1]

				// 如果两张牌的内容不一样，翻回去
				if (card1.querySelector(".front").innerText !== card2.querySelector(".front")
					.innerText) {
					setTimeout(function() {
						card1.classList.remove("open")
						card2.classList.remove("open")
						openedCards = []
					}, 900)
				} else {
					// 如果两张牌的内容一样，保持翻开状态
					openedCards = []
				}
			}
		})
	})

	let gameTimer
	const $timeLog = document.getElementById("timeLog")
	document.getElementById("btn").addEventListener("click", function() {
		const $btn = this
		//禁用"开始游戏"按钮, 并把其文本改成"游戏中..."
		$btn.disabled = true
		$btn.innerText = "游戏中..."
		document.getElementById("main").classList.add(
			"started") //游戏开始时, 给main上添加started样式类, 使每个poker都可以被点击
		document.querySelectorAll(".poker").forEach(function(poker) {
			//循环一下所有poker, 把open样式类都给移除掉, 回到初始化状态
			poker.classList.remove("open")
		})
		let time = 60; //初始化游戏总时长
		$timeLog.innerText = `现在还剩下${time}秒`
		gameTimer = setInterval(function() {
			//开始倒计时, 并显示在页面上
			--time
			$timeLog.innerText = `现在还剩下${time}秒`
			if (time <= 0) {
				//当倒计时结束
				$btn.disabled = false
				document.getElementById("main").classList.remove(
					"started") //把started样式类从#main上移除, 使每个poker又不能被点击了
				clearInterval(gameTimer) //清除interval计时器
				$timeLog.innerText = "游戏已结束,你失败了" //显示一下游戏结束的文字样式
				setTimeout(function () {
					alert('你失败了')
				},80)
				
				$btn.innerText = "开始游戏" //把按钮文字改回去
			}	
			let gameover = 0
	Array.from($(".poker")).forEach(function(poker) {
		if (poker.classList.contains("open")) gameover++
		// 如果总数等于当前poker数量, 则表示所有Poker都已经被配对了，弹出恭喜页面
		if (gameover === Array.from($(".poker")).length) {
			clearInterval(gameTimer)
				alert('恭喜，你赢了！点击确定刷新页面')
				location.reload()  //刷新页面
		}
	})
		}, 1000)
	})
	const btn = document.getElementById('btn')
	btn.innerHTML = '开始游戏'
})()